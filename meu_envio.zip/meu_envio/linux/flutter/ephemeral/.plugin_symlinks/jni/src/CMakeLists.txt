# jni_native_build (Build with jni:setup. Do not delete this line.)

# The Flutter tooling requires that developers have CMake 3.10 or later
# installed. You should not increase this version, as doing so will cause
# the plugin to fail to compile for some customers of the plugin.
cmake_minimum_required(VERSION 3.10)

project(jni_library VERSION 0.0.1 LANGUAGES C)

set(JNI_AVAILABLE FALSE)
if (ANDROID)
    set(JNI_AVAILABLE TRUE)
else()
    if (NOT JAVA_INCLUDE_PATH)
        set(JAVA_INCLUDE_PATH "${CMAKE_CURRENT_SOURCE_DIR}/../third_party" CACHE PATH "" FORCE)
        set(JAVA_INCLUDE_PATH2 "${CMAKE_CURRENT_SOURCE_DIR}/../third_party" CACHE PATH "" FORCE)
    endif()
    if (REQUIRE_JNI)
        # Standalone Dart Build: Fail strictly if JNI is missing
        find_package(JNI REQUIRED COMPONENTS JVM)
        set(JNI_AVAILABLE TRUE)
    else()
        # Flutter Plugin Build: Try to find JNI, but don't fail if missing
        find_package(JNI COMPONENTS JVM)
        if (JNI_FOUND)
            set(JNI_AVAILABLE TRUE)
        endif()
    endif()
endif()

if (JNI_AVAILABLE)
	add_library(jni SHARED
		"dartjni.c"
		"third_party/global_jni_env.c"
		"include/dart_api_dl.c"
	)

	set_target_properties(jni PROPERTIES
		PUBLIC_HEADER dartjni.h
		OUTPUT_NAME "dartjni"
	)

	target_compile_definitions(jni PUBLIC DART_SHARED_LIB)

	if(WIN32)
		set_target_properties(${TARGET_NAME} PROPERTIES
			LINK_FLAGS "/DELAYLOAD:jvm.dll")
	endif()

	if (ANDROID)
		target_link_libraries(jni log)
		target_link_options(jni PRIVATE "-Wl,-z,max-page-size=16384")
	elseif (CMAKE_CROSSCOMPILING)
		include_directories(${JNI_INCLUDE_DIRS})
		target_link_options(jni PRIVATE "-Wl,--allow-shlib-undefined")
	else()
		find_package(JNI REQUIRED COMPONENTS JVM)
		include_directories(${JNI_INCLUDE_DIRS})
		target_link_libraries(jni ${JNI_LIBRARIES})
	endif()
endif()
